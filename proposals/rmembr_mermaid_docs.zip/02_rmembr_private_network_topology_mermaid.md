# rMEMbr Private Network Topology — Mermaid

## Overview

This diagram shows the private-network deployment model for the Azure platform.

```mermaid
flowchart TD
    HUB[Hub / Shared Services VNet<br/>optional] --> SPOKE[rMEMbr Spoke VNet]

    subgraph SPOKE[rMEMbr Spoke VNet]
        subgraph CAENV[Subnet: container-apps-env]
            G[Gateway]
            I[Index]
            S[Standards]
            W[Workers / Jobs]
        end

        subgraph PEP[Subnet: private-endpoints]
            PE1[Cosmos DB Private Endpoint]
            PE2[Blob Storage Private Endpoint]
            PE3[Redis Private Endpoint]
            PE4[Service Bus Private Endpoint]
            PE5[Key Vault Private Endpoint]
            PE6[ACR Private Endpoint]
        end

        subgraph DNS[Private DNS Zones]
            D1[privatelink.documents.azure.com]
            D2[privatelink.blob.core.windows.net]
            D3[privatelink.redis.cache.windows.net]
            D4[privatelink.servicebus.windows.net]
            D5[privatelink.vaultcore.azure.net]
            D6[privatelink.azurecr.io]
        end
    end

    G --> PE1
    G --> PE2
    G --> PE3
    G --> PE4
    G --> PE5
    G --> PE6

    I --> PE1
    I --> PE2
    I --> PE4
    I --> PE5

    W --> PE1
    W --> PE2
    W --> PE3
    W --> PE4
    W --> PE5
```
