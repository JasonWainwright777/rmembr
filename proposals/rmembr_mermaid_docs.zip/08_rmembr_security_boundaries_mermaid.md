# rMEMbr Security Boundaries — Mermaid

## Overview

This diagram shows trust and enforcement boundaries.

```mermaid
flowchart TD
    USER[Users / Tools / Agents] --> ENTRA[Entra ID]
    ENTRA --> GATE[Gateway Service]

    GATE --> AUTH[Authorization Check]
    AUTH --> CACHE[Redis Cache]
    AUTH --> INDEX[Index / Standards Services]

    INDEX --> COSMOS[Cosmos DB]
    INDEX --> BLOB[Blob Storage]
    INDEX --> SB[Service Bus]
    INDEX --> KV[Key Vault]
    INDEX --> CONN[Source Connectors]

    subgraph Controls[Security Controls]
        C1[Managed Identity]
        C2[Private Endpoints]
        C3[Private DNS]
        C4[RBAC]
        C5[Audit / Telemetry]
    end

    GATE --> C1
    INDEX --> C1
    CACHE --> C2
    COSMOS --> C2
    BLOB --> C2
    SB --> C2
    KV --> C2
    AUTH --> C4
    GATE --> C5
    INDEX --> C5
```
