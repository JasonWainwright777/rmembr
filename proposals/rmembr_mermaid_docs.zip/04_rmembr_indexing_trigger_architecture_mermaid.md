# rMEMbr Indexing Trigger Architecture — Mermaid

## Overview

This diagram shows the event-driven indexing pattern:
- pipelines, webhooks, pollers, and admins publish normalized reindex messages
- Service Bus is the common async trigger channel
- centralized workers perform the indexing

```mermaid
flowchart TD
    ADO[ADO Pipeline<br/>.ai/** path change] --> BUS[Azure Service Bus<br/>reindex queue / topic]
    GHW[GitHub Webhook<br/>.ai/** change] --> BUS
    POLL[Confluence / Wiki / SharePoint Poller] --> BUS
    ADMIN[Manual Admin Reindex] --> BUS
    SCHED[Scheduled Refresh Job] --> BUS

    BUS --> WRK[Index Worker Service]
    WRK --> EVT[Parse normalized event]
    EVT --> SEL[Select connector by sourceType]
    SEL --> FETCH[Fetch authoritative content]
    FETCH --> NORM[Normalize / transform]
    NORM --> CHUNK[Chunk content]
    CHUNK --> EMB[Generate embeddings]
    EMB --> COSMOS[Update Cosmos vectors + metadata + pointers]
    COSMOS --> INV[Publish / execute cache invalidation]
    INV --> REDIS[Redis cache]
    INV --> BLOB[Blob cache]
```
