# rMEMbr Connector Model — Mermaid

## Overview

This diagram shows how connectors preserve source-of-truth ownership while giving rMEMbr a unified retrieval interface.

```mermaid
flowchart LR
    CDB[Cosmos DB<br/>vectors + metadata + source pointers] --> RES[Pointer resolution]
    RES --> ROUTE[Select connector]

    ROUTE --> GH[GitHub Connector]
    ROUTE --> ADO[Azure DevOps Connector]
    ROUTE --> CONF[Confluence Connector]
    ROUTE --> SP[SharePoint Connector]
    ROUTE --> OTH[Other Connector]

    GH --> GHAPI[GitHub source]
    ADO --> ADOAPI[ADO source]
    CONF --> CONFAPI[Confluence source]
    SP --> SPAPI[SharePoint source]
    OTH --> OTHAPI[Other source]

    GHAPI --> NORM[Normalize content + metadata]
    ADOAPI --> NORM
    CONFAPI --> NORM
    SPAPI --> NORM
    OTHAPI --> NORM

    NORM --> GOV[Governance overlay / policy context]
    GOV --> BUNDLE[Bundle assembly]
```
