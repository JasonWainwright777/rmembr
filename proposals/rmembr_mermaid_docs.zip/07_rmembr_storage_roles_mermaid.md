# rMEMbr Storage Roles — Mermaid

## Overview

This diagram clarifies the role of Cosmos, Blob, and Redis.

```mermaid
flowchart TD
    subgraph SourceOfTruth[Systems of Record]
        GH[GitHub]
        ADO[Azure DevOps]
        CONF[Confluence]
        SP[SharePoint]
    end

    subgraph PlatformStorage[rMEMbr Platform Storage]
        COSMOS[Cosmos DB<br/>vectors + metadata + source pointers]
        BLOB[Blob Storage<br/>fetched-content cache + artifacts]
        REDIS[Redis<br/>semantic cache]
    end

    SourceOfTruth -->|authoritative content remains here| COSMOS
    COSMOS -->|points to locations| SourceOfTruth
    SourceOfTruth -->|optional fetched copies| BLOB
    COSMOS -->|drives retrieval selection| REDIS
    BLOB -->|supports faster re-fetch / artifacts| REDIS
```
