# rMEMbr Service Bus Role — Mermaid

## Overview

This diagram explains why Service Bus is necessary.

```mermaid
flowchart TD
    subgraph SyncPath[Fast synchronous path]
        C[Client Request] --> G[Gateway]
        G --> R{Redis hit?}
        R -->|Yes| RESP[Return response]
        R -->|No| RETR[Retrieve / fetch / assemble]
        RETR --> RESP
    end

    subgraph AsyncPath[Asynchronous control plane]
        EV[Change event / refresh / admin request] --> BUS[Service Bus]
        BUS --> IDX[Index workers]
        BUS --> INV[Invalidation workers]
        BUS --> REF[Refresh workers]
        BUS --> MAINT[Maintenance workers]
    end

    IDX --> COS[Cosmos update]
    INV --> RED[Redis / Blob invalidation]
    REF --> SRC[Source refresh]
    MAINT --> OPS[Operational tasks]

    note1[Service Bus keeps slow and bursty work off the user request path]
```
