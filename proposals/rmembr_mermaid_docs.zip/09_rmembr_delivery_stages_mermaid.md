# rMEMbr Delivery Stages — Mermaid

## Overview

This diagram shows the staged rollout.

```mermaid
flowchart TD
    S0[Stage 0<br/>Architecture Alignment] --> S1[Stage 1<br/>Foundation Infrastructure]
    S1 --> S2[Stage 2<br/>Core Application Deployment]
    S2 --> S3[Stage 3<br/>Connector Enablement]
    S3 --> S4[Stage 4<br/>Enterprise Security]
    S4 --> S5[Stage 5<br/>Async Processing]
    S5 --> S6[Stage 6<br/>Semantic Cache]
    S6 --> S7[Stage 7<br/>Optimization]

    S0 --> A0[Confirm standards, connector model, env model]
    S1 --> A1[Bicep deploy VNet, Cosmos, Blob, Redis, Service Bus, Key Vault, CA Env]
    S2 --> A2[Deploy Gateway, Index, Standards, Workers]
    S3 --> A3[Enable GitHub / ADO / Confluence connectors]
    S4 --> A4[Entra auth, MI, RBAC, audit]
    S5 --> A5[Queue-driven indexing and refresh]
    S6 --> A6[Redis semantic cache + Blob cache strategy]
    S7 --> A7[Tune partitions, TTLs, fetch strategy, scale]
```
