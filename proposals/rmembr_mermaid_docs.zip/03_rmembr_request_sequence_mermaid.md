# rMEMbr Request Sequence — Mermaid

## Overview

This sequence shows the synchronous retrieval path.

```mermaid
sequenceDiagram
    autonumber
    participant Client as Client / Tool / Agent
    participant Gateway as Gateway Service
    participant Redis as Redis Semantic Cache
    participant Index as Index / Standards Service
    participant Cosmos as Cosmos Vector Search
    participant Connector as Source Connector
    participant Source as Source System
    participant Blob as Blob Cache / Artifacts

    Client->>Gateway: Request context
    Gateway->>Gateway: Validate identity + authorization
    Gateway->>Redis: Lookup cache key

    alt Cache hit
        Redis-->>Gateway: Cached scoped bundle
        Gateway-->>Client: Return bundle
    else Cache miss
        Gateway->>Index: Resolve request
        Index->>Cosmos: Query vectors + source pointers
        Cosmos-->>Index: Matching locations + metadata
        Index->>Connector: Fetch authoritative content
        Connector->>Source: Get content by pointer
        Source-->>Connector: Content
        Connector-->>Index: Normalized content
        Index->>Blob: Optionally cache fetched content / artifacts
        Index->>Index: Assemble bundle + governance context
        Index->>Redis: Write eligible cache entry
        Index-->>Gateway: Final scoped bundle
        Gateway-->>Client: Return bundle
    end
```
