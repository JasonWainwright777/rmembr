# rMEMbr Overall Architecture — Mermaid

## Overview

This diagram shows the enterprise Azure target state for rMEMbr as a **federated context delivery platform**.

Key points:
- source systems remain the systems of record
- Cosmos stores vectors, metadata, and source pointers
- Blob is primarily a cache/artifact layer
- Redis is the semantic cache
- Service Bus drives async work
- reasoning/inference remains outside the platform boundary

```mermaid
flowchart TD
    U[Users / Tools / Agents / CI-CD / Automation] --> E[Microsoft Entra ID]
    E --> APIM[Azure API Management<br/>optional]
    APIM --> G[Gateway Service<br/>Azure Container Apps]

    G --> RC{Redis cache hit?}
    RC -->|Yes| R[Return scoped context bundle]
    RC -->|No| IDX[Index / Standards Services<br/>Azure Container Apps]

    IDX --> CDB[Azure Cosmos DB<br/>Vector Search + Metadata + Source Pointers]
    CDB --> CONN[Connector Layer]

    CONN --> GH[GitHub]
    CONN --> ADO[Azure DevOps Repos / Wikis]
    CONN --> CONF[Confluence]
    CONN --> SP[SharePoint]
    CONN --> OTH[Other Enterprise Sources]

    GH --> SRC[Authoritative source content]
    ADO --> SRC
    CONF --> SRC
    SP --> SRC
    OTH --> SRC

    SRC --> BLOB[Azure Blob Storage<br/>Optional cache / artifacts]
    BLOB --> ASM[Bundle Assembly + Governance Context]
    ASM --> REDIS[Azure Managed Redis<br/>Semantic Cache]
    REDIS --> R

    SB[Azure Service Bus] --> WK[Worker Services / Jobs<br/>Azure Container Apps]
    WK --> CDB
    WK --> BLOB
    WK --> REDIS
    WK --> CONN
```
