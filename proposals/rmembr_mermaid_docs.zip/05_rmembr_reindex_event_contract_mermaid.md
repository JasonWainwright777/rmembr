# rMEMbr Reindex Event Contract — Mermaid

## Overview

This diagram documents the normalized event contract conceptually.

```mermaid
classDiagram
    class ReindexRequestedEvent {
        +string eventType
        +string sourceType
        +string sourceId
        +string location
        +string scope
        +string tenant
        +string namespace
        +string changeType
        +string version
        +string requestedBy
        +datetime requestedAt
        +map additionalMetadata
    }

    class SourceTypes {
        azure-devops-repo
        github-repo
        confluence
        sharepoint
        ado-wiki
        other
    }

    class ScopeTypes {
        file
        document
        repository
        namespace
        refresh
    }

    class ChangeTypes {
        created
        modified
        deleted
        refresh
    }

    ReindexRequestedEvent --> SourceTypes
    ReindexRequestedEvent --> ScopeTypes
    ReindexRequestedEvent --> ChangeTypes
```

## Example JSON

```json
{
  "eventType": "reindex.requested",
  "sourceType": "azure-devops-repo",
  "sourceId": "project/repo",
  "location": ".ai/memory/design.md",
  "scope": "file",
  "tenant": "enterprise",
  "namespace": "platform-team",
  "changeType": "modified",
  "version": "commit-sha",
  "requestedBy": "pipeline"
}
```
